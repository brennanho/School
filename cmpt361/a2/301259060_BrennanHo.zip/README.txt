Questions (f) and (g): incomplete.

Questions (d) and (e): The lighting on the bunny is a combination of the 2 light sources i.e. the rotating cube around
the bunnies head and the panning cone at (0, 4, 2).