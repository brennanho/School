Brennan Ho
301259060
bmh6@sfu.ca

Programming Assignment #1 - Space Invaders

Open Source Used:

'Common' files used found on course website
1)initShaders.js
2)MV.js
3)webgl-utils.js



Game Instructions:

Left Key - Moves green cannon left
Right Key - Moves green cannon right
Left Click - Shoots cannon ball upwards toward aliens
r - Restarts the game
q - Closes the tab and quits the game



Extra Notes:

The player (green cannon) can only shoot 3 cannon balls at a time i.e. there cannot be more than 3 cannon balls on the screen at a time. This is to ensure the game does not become to easy. The aliens shoot every second together as to balance difficulty. 