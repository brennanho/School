def reducer (key, list_of_vals):
	return [(key, len(list_of_vals))]