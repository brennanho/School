def reducer (key, list_of_vals):
	return [(key, list_of_vals[0][0], list_of_vals[0][1])]